<?php

namespace Packt\ProductSlider\Block\Catalog\Product;

class ProductSlider extends \Magento\Catalog\Block\Product\ListProduct {

}