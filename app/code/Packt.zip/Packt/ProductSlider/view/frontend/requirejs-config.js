var config = {
    map: {
        '*': {
            slick: 'Packt_ProductSlider/js/slick'
        }
    }
};